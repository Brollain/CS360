package com.cs360.eventtrackingbrollain.models;

import com.cs360.eventtrackingbrollain.R;

public class SavedEvent {
    private String datePicker;
    private String titleEvent;
    private String noteLooker;

    public SavedEvent(String datePicker, String titleEvent, String noteLooker) {
        this.datePicker = datePicker;
        this.titleEvent = titleEvent;
        this.noteLooker = noteLooker;
    }

    public SavedEvent() {
        this.datePicker = "";
        this.titleEvent = "";
        this.noteLooker = "";
    }

    public void setDatePicker(String datePicker) {
        this.datePicker = datePicker;
    }

    public void setTitleEvent(String title) {
        this.titleEvent = title;
    }

    public void setNotes(String notes) {
        this.noteLooker = notes;
    }

    public String getDatePicker() {
        return this.datePicker;
    }

    public String getTitleEvent() {
        return this.titleEvent;
    }

    public String getNotes() {
        return this.noteLooker;
    }
}

