package com.cs360.eventtrackingbrollain.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cs360.eventtrackingbrollain.R;
import com.cs360.eventtrackingbrollain.models.Constants;
import com.cs360.eventtrackingbrollain.models.SavedNotif;

public class ManageNotifications extends AppCompatActivity {
    CheckBox notifs;
    Button buttonSaveNotif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_notifications);

        SavedNotif event = getNotif();

        notifs = findViewById(R.id.checkBox);
        buttonSaveNotif = findViewById(R.id.buttonSaveNotif);

        notifs.setChecked((event.getNotification()));

        buttonSaveNotif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Boolean readNotifications = notifs.isChecked();
                saveNotif(readNotifications);

                finish();
            }
        });
        buttonSaveNotif.setEnabled(true);

}

    private void saveNotif(Boolean notifs) {
        SharedPreferences sharedPrefs;

        sharedPrefs = getSharedPreferences("EventTrackingBRollain", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPrefs.edit();

        editor.putBoolean(Constants.EVENT_NOTIF, notifs);
        editor.apply();

    }

    private SavedNotif getNotif() {
        SavedNotif savedNotif = new SavedNotif();


        SharedPreferences sharedPrefs = getSharedPreferences("EventTrackingBRollain", Context.MODE_PRIVATE);

        savedNotif.setNotifications(sharedPrefs.getBoolean(Constants.EVENT_NOTIF, false));

        return savedNotif;
    }

}
