package com.cs360.eventtrackingbrollain.models;

import android.widget.Button;

import java.util.ArrayList;
import java.util.Calendar;

public class Event {

    private long id;
    private String eventDate;
    private String eventTitle;
    private String eventActivity;

    public Event(long id, String eventDate, String eventTitle, String eventActivity){
        this.eventDate = eventDate;
        this.eventTitle = eventTitle;
        this.eventActivity = eventActivity;
        this.id = id;
    }

    public Event(){
        this.eventDate = "";
        this.eventTitle = "";
        this.eventActivity = "";
        this.id = 0;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setEventDate (String eventDate){
        this.eventDate = eventDate;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public void setEventActivity(String eventActivity) {
        this.eventActivity = eventActivity;
    }

    public long getId() {return this.id;}

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventActivity() {
        return eventActivity;
    }

    public static ArrayList<Event> getDummyEvents() {

        ArrayList<Event> dummyEvents = new ArrayList<>();
        String date = "AUG 22, 2024";
        dummyEvents.add(new Event(1, date, "Friend Time",
                "Time to chill with friends"));
        date = "AUG 28, 2024";
        dummyEvents.add(new Event(2, date, "Art",
                "Make that bread"));
        date = "SEP 2, 2024";
        dummyEvents.add(new Event(3, date, "Party",
                "Fun?"));
        date = "SEP 8, 2024";
        dummyEvents.add(new Event(4, date, "Dentist",
                "I flossed this time!"));
        date = "SEP 13, 2024";
        dummyEvents.add(new Event(5, date, "Project",
                "Overtime work!"));
        date = "SEP 28, 2024";
        dummyEvents.add(new Event(6, date, "Chill",
                "Just relax"));
        date = "Oct 2, 2024";
        dummyEvents.add(new Event(7, date, "Vacation Start",
                "Gonna be weird to not work"));
        date = "OCT 14, 2024";
        dummyEvents.add(new Event(8, date, "Vacation Ends",
                "Is it ever enough time to relax?"));

        return dummyEvents;
    }

    public void update(Event updatedEvent) {
        // Update the properties of this event with the values from the updatedEvent
        this.eventDate = updatedEvent.getEventDate();
        this.eventTitle = updatedEvent.getEventTitle();
        this.eventActivity = updatedEvent.getEventActivity();
    }

}
