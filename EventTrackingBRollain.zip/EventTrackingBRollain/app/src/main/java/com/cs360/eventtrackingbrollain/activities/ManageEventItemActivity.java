package com.cs360.eventtrackingbrollain.activities;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cs360.eventtrackingbrollain.R;
import com.cs360.eventtrackingbrollain.models.Constants;
import com.cs360.eventtrackingbrollain.models.Event;
import com.cs360.eventtrackingbrollain.models.SavedEvent;

import java.util.ArrayList;
import java.util.Calendar;

public class ManageEventItemActivity extends AppCompatActivity {

    final Calendar myCalendar = Calendar.getInstance();
    public EditText datePicker;
    public EditText title;
    public EditText noteLooker;
    long id = 0;
    Button buttonSaveEvents;
    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // check to see if the editTexts are empty
            String eventDateCountString = datePicker.getText().toString();
            String eventTitleCountString = title.getText().toString();
            String eventNoteCountString = noteLooker.getText().toString();
            // validates editTexts are not empty
            buttonSaveEvents.setEnabled(!eventDateCountString.isEmpty() &&
                    !eventTitleCountString.isEmpty() && !eventNoteCountString.isEmpty());
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_event);

        datePicker = findViewById(R.id.addTextDate);
        title = findViewById(R.id.addTextTitle);
        noteLooker = findViewById(R.id.addTextNotes);
        buttonSaveEvents = findViewById(R.id.buttonSave);

        // initialize with empty values
        datePicker.setText("");
        title.setText("");
        noteLooker.setText("");

        getEvent();

        // Makes sure that the editTexts are not empty
        datePicker.addTextChangedListener(textWatcher);
        title.addTextChangedListener(textWatcher);
        noteLooker.addTextChangedListener(textWatcher);
        // manage date format
        selectDate();

        buttonSaveEvents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eventDateCountString = datePicker.getText().toString();
                String eventTitleCountString = title.getText().toString();
                String eventNoteCountString = noteLooker.getText().toString();

                Log.d("debug", "** date: " + eventDateCountString);
                Log.d("debug", "*** title: " + eventTitleCountString);
                Log.d("debug", "**** notes: " + eventNoteCountString);
                if(eventDateCountString.isEmpty()){
                    Toast.makeText(ManageEventItemActivity.this, "Please enter a date.", Toast.LENGTH_SHORT).show();
                    buttonSaveEvents.setEnabled(false);
                }
                if(eventTitleCountString.isEmpty()){
                    Toast.makeText(ManageEventItemActivity.this, "Please enter a title.", Toast.LENGTH_SHORT).show();
                    buttonSaveEvents.setEnabled(false);
                }
                if(eventNoteCountString.isEmpty()){
                    Toast.makeText(ManageEventItemActivity.this, "Please enter notes.", Toast.LENGTH_SHORT).show();
                    buttonSaveEvents.setEnabled(false);
                }

                saveEvent(eventDateCountString, eventTitleCountString, eventNoteCountString);

                finish();
            }
        });
    }

    private void saveEvent(String datePicker, String title, String noteLooker) {
        /* SharedPreferences sharedPrefs;

        sharedPrefs = getSharedPreferences("EventTrackingBRollain", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPrefs.edit();

        editor.putString(Constants.EVENT_DATE, datePicker);
        editor.putString(Constants.EVENT_TITLE, title);
        editor.putString(Constants.EVENT_ACTIVITY, noteLooker);
        editor.apply();
        */

        Intent intent = new Intent();

        intent.putExtra(Constants.EVENT_DATE, datePicker);
        intent.putExtra(Constants.EVENT_TITLE, title);
        intent.putExtra(Constants.EVENT_ACTIVITY, noteLooker);
        intent.putExtra(Constants.EVENT_ID, id);
        setResult(Activity.RESULT_OK, intent);

    }

/*
    private SavedEvent getEvent() {
        SavedEvent savedEvent = new SavedEvent();



        SharedPreferences sharedPrefs = getSharedPreferences("EventTrackingBRollain", Context.MODE_PRIVATE);

        savedEvent.setDatePicker(sharedPrefs.getString(Constants.EVENT_DATE, ""));
        savedEvent.setTitleEvent(sharedPrefs.getString(Constants.EVENT_TITLE, ""));
        savedEvent.setNotes(sharedPrefs.getString(Constants.EVENT_ACTIVITY, ""));

        return savedEvent;


    }

*/
    private void getEvent(){
        // Retrieve the event data from the Intent
        Intent intent = getIntent();
        String eventDate = intent.getStringExtra(Constants.EVENT_DATE);
        String eventTitle = intent.getStringExtra(Constants.EVENT_TITLE);
        String eventActivity = intent.getStringExtra(Constants.EVENT_ACTIVITY);
        this.id = intent.getLongExtra(Constants.EVENT_ID, 0);

        // Add logs to check if data is retrieved correctly
        Log.d("ManageEventItemActivity", "Received eventDate: " + eventDate);
        Log.d("ManageEventItemActivity", "Received eventTitle: " + eventTitle);
        Log.d("ManageEventItemActivity", "Received eventActivity: " + eventActivity);

        // Set the EditText fields with the event data
        if (eventDate != null) {
            datePicker.setText(eventDate);
        }
        if (eventTitle != null) {
            title.setText(eventTitle);
        }
        if (eventActivity != null) {
            noteLooker.setText(eventActivity);
        }

    }

    private void selectDate(){
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String date = makeDateString(dayOfMonth, month, year);
                datePicker.setText(date);
            }
        };

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(ManageEventItemActivity.this, date,
                        myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });
    }

    private String makeDateString(int day, int month, int year){
        return getMonthFormat(month) + " " + day + ", " + year;
    }

    private String getMonthFormat(int month) {
        if (month == 0)
            return "JAN";
        if (month == 1)
            return "FEB";
        if (month == 2)
            return "MAR";
        if (month == 3)
            return "APR";
        if (month == 4)
            return "MAY";
        if (month == 5)
            return "JUN";
        if (month == 6)
            return "JUL";
        if (month == 7)
            return "AUG";
        if (month == 8)
            return "SEP";
        if (month == 9)
            return "OCT";
        if (month == 10)
            return "NOV";
        if (month == 11)
            return "DEC";
        // default should never happen
        return "ERR";
    }
}