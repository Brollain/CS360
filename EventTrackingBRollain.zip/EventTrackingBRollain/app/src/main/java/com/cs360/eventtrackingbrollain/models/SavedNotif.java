package com.cs360.eventtrackingbrollain.models;

import com.cs360.eventtrackingbrollain.R;

public class SavedNotif {

    Boolean settingNotif;

    public SavedNotif(Boolean notifications) {
        this.settingNotif = notifications;
    }

    public SavedNotif() {
        this.settingNotif = false;
    }

    public void setNotifications(Boolean notifications) {
        this.settingNotif = notifications;
    }

    public Boolean getNotification() {
        return this.settingNotif;
    }

}
