package com.cs360.eventtrackingbrollain.models;

public class Constants {
    public static final String EVENT_DATE = "EVENT_DATE";
    public static final String EVENT_TITLE = "EVENT_TITLE";
    public static final String EVENT_ACTIVITY = "EVENT_ACTIVITY";
    public static final String EVENT_ID = "EVENT_ID";

    public static final String EVENT_NOTIF = "EVENT_NOTIF";
}