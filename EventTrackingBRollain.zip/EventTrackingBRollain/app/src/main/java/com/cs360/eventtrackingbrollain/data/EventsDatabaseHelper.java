package com.cs360.eventtrackingbrollain.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.cs360.eventtrackingbrollain.models.Event;

import java.util.ArrayList;

public class EventsDatabaseHelper extends SQLiteOpenHelper {
    // create a simple singleton that allows us to access the helper in  different activities
    // without always having to initializze it.
    private static EventsDatabaseHelper helper;

    public static EventsDatabaseHelper getInstance(Context context) {
        if(helper == null)
            helper = new EventsDatabaseHelper(context);
        return helper;
    }

    private static final String DATABASE_NAME = "events.db";
    private static final int DATABASE_VERSION = 1;
    public EventsDatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public class EventsTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id"; // primary key
        private static final String COL_TITLE = "event_title";
        private static final String COL_DATE = "event_date";
        private static final String COL_NOTE = "event_note";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + EventsTable.TABLE + " (" +
                EventsTable.COL_ID + " Integer primary key autoincrement, " +
                EventsTable.COL_TITLE + " text, " +
                EventsTable.COL_DATE + " text, " +
                EventsTable.COL_NOTE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventsTable.TABLE);
        onCreate(db);
    }

    public void getAllEvents(ArrayList<Event> events) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + EventsTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String title = cursor.getString(1);
                String date = cursor.getString(2);
                String note = cursor.getString(3);
                events.add(new Event(id, date, title, note));

            } while (cursor.moveToNext());
        }

        cursor.close();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
    public long add(Event event) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EventsTable.COL_TITLE, event.getEventTitle());
        values.put(EventsTable.COL_DATE, event.getEventDate());
        values.put(EventsTable.COL_NOTE, event.getEventActivity());

        long id = db.insert(EventsTable.TABLE, null, values);
        event.setId(id);

        db.close(); // always close the database after use

        return id;
    }

    public Boolean update(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(EventsTable.COL_TITLE, event.getEventTitle());
        values.put(EventsTable.COL_DATE, event.getEventDate());
        values.put(EventsTable.COL_NOTE, event.getEventActivity());

        int rowsUpdated = db.update(EventsTable.TABLE, values, "_id = ?",
                new String[]{Long.toString(event.getId())}
        );

        db.close();

        return rowsUpdated > 0;
    }


    public Boolean delete(Event event) {
        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(EventsTable.TABLE, EventsTable.COL_ID + " = ?",
                new String[]{Long.toString(event.getId())}
        );

        db.close();

        return rowsDeleted > 0;
    }



}
