package com.cs360.eventtrackingbrollain.adapters;

import static com.cs360.eventtrackingbrollain.models.Event.getDummyEvents;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.cs360.eventtrackingbrollain.R;
import com.cs360.eventtrackingbrollain.models.Event;

import java.util.ArrayList;
import java.util.List;

public class EventListAdapter extends ArrayAdapter<Event> {

    public EventListAdapter(@NonNull Context context, int resource, @NonNull List<Event> events){
        super(context, resource, events);
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View listView = convertView;

        if(listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.event_list_item, parent, false);
        }

        // get views and set to the current object values
        TextView title = listView.findViewById(R.id.textViewTitle);
        TextView date = listView.findViewById(R.id.textViewDate);
        TextView notes = listView.findViewById(R.id.textViewNotes);

        Event currentEvent = getItem(position);

        title.setText(currentEvent.getEventTitle());
        date.setText(currentEvent.getEventDate());
        notes.setText(currentEvent.getEventActivity());

        return listView;
    }

}
