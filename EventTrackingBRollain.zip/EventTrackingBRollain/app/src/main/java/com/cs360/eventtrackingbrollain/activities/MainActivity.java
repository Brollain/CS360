package com.cs360.eventtrackingbrollain.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.cs360.eventtrackingbrollain.R;
import com.cs360.eventtrackingbrollain.adapters.EventListAdapter;
import com.cs360.eventtrackingbrollain.models.Event;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.cs360.eventtrackingbrollain.models.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    ArrayList<Event> events = Event.getDummyEvents();
    GridView eventsGridView;
    FloatingActionButton fabAdd;
    private EventListAdapter adapter;

    ActivityResultLauncher genericActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        events = Event.getDummyEvents();
        adapter = new EventListAdapter(this, R.layout.event_list_item, events);

        eventsGridView = (GridView)findViewById(R.id.eventListView);

        //adapter will hold our data for us
        eventsGridView.setAdapter(adapter);

        eventsGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // use position to get the selected event

                Event event = events.get(position);
                if(null != event){
                    launchAddEventActivity(event);
                }
            }
        });

        fabAdd = findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> launchAddEventActivity(new Event()));

        initLauncher();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.events_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.event_settings){
            // launch the settings menu
            Intent intent = new Intent(this, ManageNotifications.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    private void launchAddEventActivity(Event event){
        Intent intent = new Intent(getApplicationContext(), ManageEventItemActivity.class);

        intent.putExtra(Constants.EVENT_DATE, event.getEventDate());
        intent.putExtra(Constants.EVENT_TITLE, event.getEventTitle());
        intent.putExtra(Constants.EVENT_ACTIVITY, event.getEventActivity());
        intent.putExtra(Constants.EVENT_ID, event.getId());

        Log.d("Debug:: ", "Event ID: " + event.getId());

        genericActivityLauncher.launch(intent);
    }

    private void initLauncher() {
        genericActivityLauncher =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        result ->
                        {
                            if(result.getResultCode()== Activity.RESULT_OK) {
                                Intent intent = result.getData();
                                if(null != intent) {
                                    handleResults(intent);
                                }
                            }
                        });
    }

    private void handleResults(Intent i) {
        Event event = new Event();
        event.setEventDate(i.getStringExtra(Constants.EVENT_DATE));
        event.setEventTitle(i.getStringExtra(Constants.EVENT_TITLE));
        event.setEventActivity(i.getStringExtra(Constants.EVENT_ACTIVITY));
        event.setId(i.getLongExtra(Constants.EVENT_ID, 0));

        Log.d("debug", "Recieved event information " + event.getEventTitle());
        Log.d("Debug:: ", "Event ID: " + event.getId());

        if(event.getId() == 0) {
            events.add(event);
            Toast.makeText(this, "Event Saved!", Toast.LENGTH_LONG).show();
        } else {
                // Update the existing event
                for (Event e : events) {
                    if (e.getId() == event.getId()) {
                        e.update(event);
                        Log.d("debug", "Updated event" + e.getId());
                        break; // Exit the loop once the event is found
                    }
                }
           Toast.makeText(this, "Event Updated!", Toast.LENGTH_LONG).show();
        }
        adapter.notifyDataSetChanged();
    }
}